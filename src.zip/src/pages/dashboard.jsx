import React from 'react';

const dashboard = () => {
  let b = localStorage.getItem('email')
  let c = localStorage.getItem('pass')
  return (
    <>
    {b}{c}

    </>
  )
}

export default dashboard;