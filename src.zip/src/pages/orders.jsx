import React from 'react'

const orders = () => {
  return (
    <div>
      
    </div>
  )
}

export default orders;
