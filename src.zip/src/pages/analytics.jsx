import React from 'react'

const analytics = () => {
  return (
    <div>analytics</div>
  )
}

export default analytics;