import React from 'react'

const reviews = () => {
  return (
    <div>
      
    </div>
  )
}

export default reviews;
