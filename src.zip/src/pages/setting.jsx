import React from 'react'

const setting = () => {
  return (
    <div>setting</div>
  )
}

export default setting;