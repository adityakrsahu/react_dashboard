import React from 'react'
import { Link, Outlet } from 'react-router-dom';
import '../../assets/styles/index.css';


const Sidebar = () => {
  return (
    <>
        <aside id='sidebar'>        
                <ul>
                    <li> <Link to='/' style={{display:"none"}}>Login</Link> </li>
                    <li> <Link to='/registration' style={{display:"none"}} >Registration</Link></li>
                    <li> <Link to='/dashboard'>Dashboard</Link> </li>
                    <li> <Link to='/products'>products</Link> </li>
                    <li> <Link to='/orders'>Orders</Link> </li>
                    <li> <Link to='/customers'>Customers</Link> </li>
                    <li> <Link to='/analytics'>Analytics</Link> </li>
                    <li> <Link to='/reviews'>Reviews</Link> </li>
                    <li> <Link to='/setting'>Setting</Link> </li>
                </ul>
            <Outlet/>
        </aside>     
    </>
  )
}

export default Sidebar;
