const Top = () => {
  return (
    <>
    <center><aside style={{float:"top", fontSize:"50px" , backgroundColor:"rgb(46, 46, 54)",color:'white'}}>
        Admin Dashboard
    </aside> </center>
      
    </>
  )
}

export default Top;
